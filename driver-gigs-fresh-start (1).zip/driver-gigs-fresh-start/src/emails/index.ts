// Export all auth templates
export * from './auth';

// You can add more email categories here in the future
// export * from './notifications';
// export * from './marketing';
// export * from './system';
